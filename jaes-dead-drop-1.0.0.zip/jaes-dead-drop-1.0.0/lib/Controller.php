<?php declare(strict_types=1);
/**
 * Jae's Dead Drop
 *
 * a zero-knowledge paste bin
 *
 * @link      https://github.com/JaeSwiftxyz/jaes-dead-drop
 * @copyright 2026 JaeSwift (jaeswift.xyz)
 * @license   https://www.opensource.org/licenses/zlib-license.php The zlib/libpng License
 */

namespace JaesDeadDrop;

use Exception;
use JaesDeadDrop\Exception\TranslatedException;
use JaesDeadDrop\Persistence\ServerSalt;
use JaesDeadDrop\Persistence\TrafficLimiter;
use JaesDeadDrop\Proxy\AbstractProxy;
use JaesDeadDrop\Proxy\ChhotoProxy;
use JaesDeadDrop\Proxy\ShlinkProxy;
use JaesDeadDrop\Proxy\YourlsProxy;

/**
 * Controller
 *
 * Puts it all together.
 */
class Controller
{
    /**
     * version
     *
     * @const string
     */
    const VERSION = '1.0.0';

    /**
     * minimal required PHP version
     *
     * @const string
     */
    const MIN_PHP_VERSION = '7.4.0';

    /**
     * show the same error message if the document expired or does not exist
     *
     * @const string
     */
    const GENERIC_ERROR = 'Document does not exist, has expired or has been deleted.';

    /**
     * configuration
     *
     * @access private
     * @var    Configuration
     */
    private $_conf;

    /**
     * error message
     *
     * @access private
     * @var    string
     */
    private $_error = '';

    /**
     * status message
     *
     * @access private
     * @var    string
     */
    private $_status = '';

    /**
     * status message
     *
     * @access private
     * @var    bool
     */
    private $_is_deleted = false;

    /**
     * JSON message
     *
     * @access private
     * @var    string
     */
    private $_json = '';

    /**
     * Factory of instance models
     *
     * @access private
     * @var    Model
     */
    private $_model;

    /**
     * request
     *
     * @access private
     * @var    Request
     */
    private $_request;

    /**
     * URL base
     *
     * @access private
     * @var    string
     */
    private $_urlBase;

    /**
     * constructor
     *
     * initializes and runs Jae's Dead Drop
     *
     * @param ?Configuration $config
     *
     * @access public
     * @throws Exception
     */
    public function __construct(?Configuration $config = null)
    {
        if (version_compare(PHP_VERSION, self::MIN_PHP_VERSION, '<')) {
            error_log(I18n::_('%s requires php %s or above to work. Sorry.', I18n::_('Jae\'s Dead Drop'), self::MIN_PHP_VERSION));
            return;
        }
        if (strlen(PATH) > 0 && substr(PATH, -1) !== DIRECTORY_SEPARATOR) {
            error_log(I18n::_('%s requires the PATH to end in a "%s". Please update the PATH in your index.php.', I18n::_('Jae\'s Dead Drop'), DIRECTORY_SEPARATOR));
            return;
        }

        // load config (using ini file by default) & initialize required classes
        $this->_conf = $config ?? new Configuration();
        $this->_init();

        switch ($this->_request->getOperation()) {
            case 'create':
                $this->_create();
                break;
            case 'delete':
                $this->_delete(
                    $this->_request->getParam('pasteid'),
                    $this->_request->getParam('deletetoken')
                );
                break;
            case 'read':
                $this->_read($this->_request->getParam('pasteid'));
                break;
            case 'jsonld':
                $this->_jsonld($this->_request->getParam('jsonld'));
                return;
            case 'yourlsproxy':
                $this->_shortenerproxy(new YourlsProxy($this->_conf, $this->_request->getParam('link')));
                break;
            case 'shlinkproxy':
                $this->_shortenerproxy(new ShlinkProxy($this->_conf, $this->_request->getParam('link')));
                break;
            case 'chhotoproxy':
                $this->_shortenerproxy(new ChhotoProxy($this->_conf, $this->_request->getParam('link')));
                break;
        }

        $this->_setCacheHeaders();

        // output JSON or HTML
        if ($this->_request->isJsonApiCall()) {
            header('Content-type: ' . Request::MIME_JSON);
            header('Access-Control-Allow-Origin: *');
            header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
            header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
            header('X-Content-Type-Options: nosniff');
            header('X-Uncompressed-Content-Length: ' . strlen($this->_json));
            header('Access-Control-Expose-Headers: X-Uncompressed-Content-Length');
            echo $this->_json;
        } else {
            $this->_view();
        }
    }

    /**
     * initialize Jae's Dead Drop
     *
     * @access private
     * @throws Exception
     */
    private function _init()
    {
        $this->_model = new Model($this->_conf);
        $this->_request = new Request;
        $this->_urlBase = $this->_request->getRequestUri();

        $this->_setDefaultLanguage();
        $this->_setDefaultTemplate();
    }

    /**
     * Set default language
     *
     * @access private
     * @throws Exception
     */
    private function _setDefaultLanguage()
    {
        $lang = $this->_conf->getKey('languagedefault');
        I18n::setLanguageFallback($lang);
        // force default language, if language selection is disabled and a default is set
        if (!$this->_conf->getKey('languageselection') && (
            in_array($lang, I18n::getAvailableLanguages(), true) ||
            $lang === 'en'
        )) {
            $_COOKIE['lang'] = $lang;
            setcookie('lang', $lang, ['SameSite' => 'Lax', 'Secure' => true]);
        }
    }

    /**
     * Set default template
     *
     * @access private
     * @throws Exception
     */
    private function _setDefaultTemplate()
    {
        $templates = $this->_conf->getKey('availabletemplates');
        $template = $this->_conf->getKey('template');
        if (!in_array($template, $templates, true)) {
            $templates[] = $template;
        }
        TemplateSwitcher::setAvailableTemplates($templates);
        TemplateSwitcher::setTemplateFallback($template);

        // force default template, if template selection is disabled
        if (!$this->_conf->getKey('templateselection') && array_key_exists('template', $_COOKIE)) {
            unset($_COOKIE['template']); // ensure value is not re-used in template switcher
            $expiredInAllTimezones = time() - 86400;
            setcookie('template', '', ['expires' => $expiredInAllTimezones, 'SameSite' => 'Lax', 'Secure' => true]);
        }
    }

    /**
     * Turn off browser caching
     *
     * @access private
     */
    private function _setCacheHeaders()
    {
        // set headers to disable caching
        $time = gmdate('D, d M Y H:i:s \G\M\T');
        header('Cache-Control: no-store, no-cache, no-transform, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: ' . $time);
        header('Last-Modified: ' . $time);
        header('Vary: Accept');
    }

    /**
     * Store new paste or comment
     *
     * POST contains:
     * JSON encoded object with mandatory keys:
     *   v = 2 (version)
     *   adata (array)
     *   ct (base64 encoded, encrypted text)
     * meta (optional):
     *   expire = expiration delay (never,5min,10min,1hour,1day,1week,1month,1year,burn) (default:1week)
     * parentid (optional) = in discussions, which comment this comment replies to.
     * pasteid (optional) = in discussions, which paste this comment belongs to.
     *
     * @access private
     * @throws Exception
     * @return string
     */
    private function _create()
    {
        // Ensure last paste from visitors IP address was more than configured amount of seconds ago.
        ServerSalt::setStore($this->_model->getStore());
        TrafficLimiter::setConfiguration($this->_conf);
        TrafficLimiter::setStore($this->_model->getStore());
        $data = [];
        try {
            TrafficLimiter::canPass();
            $data = $this->_request->getData($this->_conf->getKey('sizelimit'));
        } catch (TranslatedException $e) {
            $this->_json_error($e->getMessage());
            return;
        }

        $isComment = array_key_exists('pasteid', $data) &&
            !empty($data['pasteid']) &&
            array_key_exists('parentid', $data) &&
            !empty($data['parentid']);
        if (!FormatV2::isValid($data, $isComment)) {
            $this->_json_error(I18n::_('Invalid data.'));
            return;
        }

        // The user posts a comment.
        if ($isComment) {
            $paste = $this->_model->getPaste($data['pasteid']);
            if ($paste->exists()) {
                try {
                    $comment = $paste->getComment($data['parentid']);
                    $comment->setData($data);
                    $comment->store();
                    $this->_json_result($comment->getId());
                } catch (Exception $e) {
                    $this->_json_error($e->getMessage());
                }
            } else {
                $this->_json_error(I18n::_('Invalid data.'));
            }
        }
        // The user posts a standard paste.
        else {
            try {
                $this->_model->purge();
                $paste = $this->_model->getPaste();
                $paste->setData($data);
                $paste->store();
                $this->_json_result($paste->getId(), ['deletetoken' => $paste->getDeleteToken()]);
            } catch (Exception $e) {
                $this->_json_error($e->getMessage());
            }
        }
    }

    /**
     * Delete an existing document
     *
     * @access private
     * @param  string $dataid
     * @param  string $deletetoken
     */
    private function _delete($dataid, $deletetoken)
    {
        try {
            $paste = $this->_model->getPaste($dataid);
            if ($paste->exists()) {
                // accessing this method ensures that the document would be
                // deleted if it has already expired
                $paste->get();
                if (hash_equals($paste->getDeleteToken(), $deletetoken)) {
                    // Document exists and deletion token is valid: Delete the it.
                    $paste->delete();
                    $this->_status = 'Document was properly deleted.';
                    $this->_is_deleted = true;
                } else {
                    $this->_error = 'Wrong deletion token. Document was not deleted.';
                }
            } else {
                $this->_error = self::GENERIC_ERROR;
            }
        } catch (TranslatedException $e) {
            $this->_error = $e->getMessage();
        }
        if ($this->_request->isJsonApiCall()) {
            if (empty($this->_error)) {
                $this->_json_result($dataid);
            } else {
                $this->_json_error(I18n::_($this->_error));
            }
        }
    }

    /**
     * Read an existing document, only allowed via a JSON API call
     *
     * @access private
     * @param  string $dataid
     */
    private function _read($dataid)
    {
        if (!$this->_request->isJsonApiCall()) {
            return;
        }

        try {
            $paste = $this->_model->getPaste($dataid);
            if ($paste->exists()) {
                $data = $paste->get();
                if (array_key_exists('salt', $data['meta'])) {
                    unset($data['meta']['salt']);
                }
                $this->_json_result($dataid, (array) $data);
            } else {
                $this->_json_error(I18n::_(self::GENERIC_ERROR));
            }
        } catch (TranslatedException $e) {
            $this->_json_error($e->getMessage());
        }
    }

    /**
     * Display frontend.
     *
     * @access private
     * @throws Exception
     */
    private function _view()
    {
        header('Content-Security-Policy: ' . $this->_conf->getKey('cspheader'));
        header('Cross-Origin-Resource-Policy: same-origin');
        header('Cross-Origin-Embedder-Policy: require-corp');
        // disabled, because it prevents links from a document to the same site to
        // be opened. Didn't work with `same-origin-allow-popups` either.
        // See issue https://github.com/JaeSwiftxyz/jaes-dead-drop/issues/970 for details.
        // header('Cross-Origin-Opener-Policy: same-origin');
        header('Permissions-Policy: browsing-topics=()');
        header('Referrer-Policy: no-referrer');
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: deny');

        // label all the expiration options
        $expire = [];
        foreach ($this->_conf->getSection('expire_options') as $time => $seconds) {
            $expire[$time] = ($seconds === 0) ? I18n::_(ucfirst($time)) : Filter::formatHumanReadableTime($time);
        }

        // translate all the formatter options
        $formatters = array_map('JaesDeadDrop\\I18n::_', $this->_conf->getSection('formatter_options'));

        // set language cookie if that functionality was enabled
        $languageselection = '';
        if ($this->_conf->getKey('languageselection')) {
            $languageselection = I18n::getLanguage();
            setcookie('lang', $languageselection, ['SameSite' => 'Lax', 'Secure' => true]);
        }

        // set template cookie if that functionality was enabled
        $templateselection = '';
        if ($this->_conf->getKey('templateselection')) {
            $templateselection = TemplateSwitcher::getTemplate();
            setcookie('template', $templateselection, ['SameSite' => 'Lax', 'Secure' => true]);
        }

        // strip policies that are unsupported in meta tag
        $metacspheader = str_replace(
            [
                'frame-ancestors \'none\'; ',
                '; sandbox allow-same-origin allow-scripts allow-forms allow-modals allow-downloads',
            ],
            '',
            $this->_conf->getKey('cspheader')
        );

        $page = new View;
        $page->assign('CSPHEADER', $metacspheader);
        $page->assign('ERROR', I18n::_($this->_error));
        $page->assign('NAME', $this->_conf->getKey('name'));
        if (in_array($this->_request->getOperation(), ['shlinkproxy', 'yourlsproxy', 'chhotoproxy'], true)) {
            $page->assign('SHORTURL', $this->_status);
            $page->draw('shortenerproxy');
            return;
        }
        $page->assign('BASEPATH', I18n::_($this->_conf->getKey('basepath')));
        $page->assign('OGIMAGE', I18n::_($this->_conf->getKey('ogimage')));
        $page->assign('STATUS', I18n::_($this->_status));
        $page->assign('ISDELETED', $this->_is_deleted);
        $page->assign('VERSION', self::VERSION);
        $page->assign('DISCUSSION', $this->_conf->getKey('discussion'));
        $page->assign('OPENDISCUSSION', $this->_conf->getKey('opendiscussion'));
        $page->assign('MARKDOWN', array_key_exists('markdown', $formatters));
        $page->assign('SYNTAXHIGHLIGHTING', array_key_exists('syntaxhighlighting', $formatters));
        $page->assign('SYNTAXHIGHLIGHTINGTHEME', $this->_conf->getKey('syntaxhighlightingtheme'));
        $page->assign('FORMATTER', $formatters);
        $page->assign('FORMATTERDEFAULT', $this->_conf->getKey('defaultformatter'));
        $page->assign('INFO', I18n::_(str_replace("'", '"', $this->_conf->getKey('info'))));
        $page->assign('NOTICE', I18n::_($this->_conf->getKey('notice')));
        $page->assign('BURNAFTERREADINGSELECTED', $this->_conf->getKey('burnafterreadingselected'));
        $page->assign('PASSWORD', $this->_conf->getKey('password'));
        $page->assign('FILEUPLOAD', $this->_conf->getKey('fileupload'));
        $page->assign('LANGUAGESELECTION', $languageselection);
        $page->assign('LANGUAGES', I18n::getLanguageLabels(I18n::getAvailableLanguages()));
        $page->assign('TEMPLATESELECTION', $templateselection);
        $page->assign('TEMPLATES', TemplateSwitcher::getAvailableTemplates());
        $page->assign('EXPIRE', $expire);
        $page->assign('EXPIREDEFAULT', $this->_conf->getKey('default', 'expire'));
        $page->assign('URLSHORTENER', $this->_conf->getKey('urlshortener'));
        $page->assign('SHORTENBYDEFAULT', $this->_conf->getKey('shortenbydefault'));
        $page->assign('QRCODE', $this->_conf->getKey('qrcode'));
        $page->assign('EMAIL', $this->_conf->getKey('email'));
        $page->assign('HTTPWARNING', $this->_conf->getKey('httpwarning'));
        $page->assign('HTTPSLINK', 'https://' . $this->_request->getHost() . $this->_request->getRequestUri());
        $page->assign('COMPRESSION', $this->_conf->getKey('compression'));
        $page->assign('SRI', $this->_conf->getSection('sri'));
        $page->draw(TemplateSwitcher::getTemplate());
    }

    /**
     * outputs requested JSON-LD context
     *
     * @access private
     * @param string $type
     */
    private function _jsonld($type)
    {
        if (!in_array($type, [
            'comment',
            'commentmeta',
            'paste',
            'pastemeta',
            'types',
        ])) {
            $type = '';
        }
        $content = '{}';
        $file = PUBLIC_PATH . DIRECTORY_SEPARATOR . 'js' . DIRECTORY_SEPARATOR . $type . '.jsonld';
        if (is_readable($file)) {
            $content = str_replace(
                '?jsonld=',
                trim(Json::encode($this->_urlBase), '"') . '?jsonld=',
                file_get_contents($file)
            );
        }
        if ($type === 'types') {
            $content = str_replace(
                implode('", "', array_keys($this->_conf->getDefaults()['expire_options'])),
                implode('", "', array_keys($this->_conf->getSection('expire_options'))),
                $content
            );
        }

        header('Content-type: application/ld+json');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET');
        header('X-Content-Type-Options: nosniff');
        echo $content;
    }

    /**
     * prepares JSON encoded error message
     *
     * @access private
     * @param  string $error
     * @throws JsonException
     */
    private function _json_error($error)
    {
        $result = [
            'status'  => 1,
            'message' => $error,
        ];
        $this->_json = Json::encode($result);
    }

    /**
     * prepares JSON encoded result message
     *
     * @access private
     * @param  string $dataid
     * @param  array $other
     * @throws JsonException
     */
    private function _json_result($dataid, $other = [])
    {
        $result = [
            'status' => 0,
            'id'     => $dataid,
            'url'    => $this->_urlBase . '?' . $dataid,
        ] + $other;
        $this->_json = Json::encode($result);
    }

    /**
     * Proxies a link using the specified proxy class, and updates the status or error with the response.
     *
     * @access private
     * @param AbstractProxy $proxy The instance of the proxy class.
     */
    private function _shortenerproxy(AbstractProxy $proxy)
    {
        if ($proxy->isError()) {
            $this->_error = $proxy->getError();
        } else {
            $this->_status = $proxy->getUrl();
        }
    }
}
