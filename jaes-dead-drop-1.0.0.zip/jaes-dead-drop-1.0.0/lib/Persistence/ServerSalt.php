<?php declare(strict_types=1);
/**
 * Jae's Dead Drop
 *
 * a zero-knowledge paste bin
 *
 * @link      https://github.com/JaeSwiftxyz/jaes-dead-drop
 * @copyright 2026 JaeSwift (jaeswift.xyz)
 * @license   https://www.opensource.org/licenses/zlib-license.php The zlib/libpng License
 */

namespace JaesDeadDrop\Persistence;

use JaesDeadDrop\Data\AbstractData;

/**
 * ServerSalt
 *
 * This is a random string which is unique to each Jae's Dead Drop installation.
 * It is automatically created if not present.
 *
 * Salt is used:
 * - to generate unique VizHash in discussions (which are not reproductible across Jae's Dead Drop servers)
 * - to generate unique deletion token (which are not re-usable across Jae's Dead Drop servers)
 */
class ServerSalt extends AbstractPersistence
{
    /**
     * generated salt
     *
     * @access private
     * @static
     * @var    string
     */
    private static $_salt = '';

    /**
     * generate a large random hexadecimal salt
     *
     * @access public
     * @static
     * @return string
     */
    public static function generate()
    {
        return bin2hex(random_bytes(256));
    }

    /**
     * get server salt
     *
     * @access public
     * @static
     * @return string
     */
    public static function get()
    {
        if (!empty(self::$_salt)) {
            return self::$_salt;
        }

        $salt = self::$_store->getValue('salt');
        if ($salt) {
            self::$_salt = $salt;
        } else {
            self::$_salt = self::generate();
            if (!self::$_store->setValue(self::$_salt, 'salt')) {
                error_log('failed to store the server salt, delete tokens, traffic limiter and user icons won\'t work');
            }
        }
        return self::$_salt;
    }

    /**
     * set the path
     *
     * @access public
     * @static
     * @param  AbstractData $store
     */
    public static function setStore(AbstractData $store)
    {
        self::$_salt = '';
        parent::setStore($store);
    }
}
