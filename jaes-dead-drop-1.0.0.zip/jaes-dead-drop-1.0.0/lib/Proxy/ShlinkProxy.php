<?php declare(strict_types=1);
/**
 * Jae's Dead Drop
 *
 * a zero-knowledge paste bin
 *
 * @link      https://github.com/JaeSwiftxyz/jaes-dead-drop
 * @copyright 2026 JaeSwift (jaeswift.xyz)
 * @license   https://www.opensource.org/licenses/zlib-license.php The zlib/libpng License
 */

namespace JaesDeadDrop\Proxy;

use JsonException;
use JaesDeadDrop\Configuration;
use JaesDeadDrop\Json;

/**
 * ShlinkProxy
 *
 * Forwards a URL for shortening to shlink and stores the result.
 */
class ShlinkProxy extends AbstractProxy
{
    /**
     * Overrides the abstract parent function to get the proxy URL.
     *
     * @param Configuration $conf
     * @return string
     */
    protected function _getProxyUrl(Configuration $conf): string
    {
        return $conf->getKey('apiurl', 'shlink');
    }

    /**
     * Overrides the abstract parent function to get contents from Shlink API.
     *
     * @access protected
     * @param Configuration $conf
     * @param string $link
     * @return array
     */
    protected function _getProxyPayload(Configuration $conf, string $link): array
    {
        $shlink_api_key = $conf->getKey('apikey', 'shlink');

        $body = [
            'longUrl' => $link,
        ];

        try {
            return [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n" .
                            'X-Api-Key: ' . $shlink_api_key . "\r\n",
                'content' => Json::encode($body),
            ];
        } catch (JsonException $e) {
            error_log('[' . get_class($this) . '] Error encoding body: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Extracts the short URL from the shlink API response.
     *
     * @access protected
     * @param array $data
     * @return ?string
     */
    protected function _extractShortUrl(array $data): ?string
    {
        return $data['shortUrl'] ?? null;
    }
}
